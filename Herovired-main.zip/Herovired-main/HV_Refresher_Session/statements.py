"""n=10
if n<=0:
    print("less than 0")
elif n<=5:
    print("less than 5")
else:
    print("greater than 5")"""

"""students=['Jaya','Hari','Durga','Priya']
print("The student names are:")
for s in students:
    print(s)"""

dict={}
dict["location"]=input()
print(dict)
