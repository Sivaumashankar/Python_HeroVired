file=open('data.txt','a')
file.write("This line added with the help of append parameter")
file.close()