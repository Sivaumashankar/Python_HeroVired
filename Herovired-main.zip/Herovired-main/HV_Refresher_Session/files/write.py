data=open('data.txt','w')
data.write("helllooo ")
# data.write("This is new line added with the help of write function")
# data.write(" Hurray!successfully added")
data.close()
# drawback: overriding prev data