file=open('read.txt','r')
"""for line in file:
    print(line)"""
print(file.read())